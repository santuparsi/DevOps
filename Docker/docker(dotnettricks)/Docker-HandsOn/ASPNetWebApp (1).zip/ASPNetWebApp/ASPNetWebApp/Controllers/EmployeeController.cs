﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetWebApp.Controllers
{
    public class EmployeeController : Controller
    {
        //employee/index?id=1&deptId=5
        //employee/index/1/5
        public IActionResult Index(int id, int deptId)
        {
            return View();
        }
    }
}
