﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetWebApp.Controllers
{
    public class ProductController : Controller
    {
        [Route("Product/Index/{id}/{catId}")]
        [Route("product-details/{id}/{catId}")]
        public IActionResult Index(int id, int catId)
        {
            return View();
        }
    }
}
