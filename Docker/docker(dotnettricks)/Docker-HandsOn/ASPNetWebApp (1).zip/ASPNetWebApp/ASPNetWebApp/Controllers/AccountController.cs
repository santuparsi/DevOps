﻿using ASPNetWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPNetWebApp.Controllers
{
    public class AccountController : Controller
    {
        public ViewResult Login()
        {
            return View();
        }


        //[HttpPost]
        //public IActionResult Login(string Username, string Password)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        //TO DO:
        //        //return RedirectToAction("Dashboard", "Home");
        //    }
        //    return View();
        //}

        //OR
        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                //TO DO:
                //return RedirectToAction("Dashboard", "Home");
            }
            return View();
        }

        public IActionResult UserLogin(string Username, string Password)
        {
            if (ModelState.IsValid)
            {
                //TO DO:
                //return RedirectToAction("Dashboard", "Home");
            }
            return View("Login");
        }
    }
}
